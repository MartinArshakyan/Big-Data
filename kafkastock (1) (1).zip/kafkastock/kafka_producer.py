"""
kafka_producer.py
Simulates real-time stock price ticks and publishes them to a Kafka topic.

In production replace the mock KafkaProducer with:
    from kafka import KafkaProducer
    producer = KafkaProducer(
        bootstrap_servers=["localhost:9092"],
        value_serializer=lambda v: json.dumps(v).encode(),
    )
"""

import json
import time
import random
import threading
import logging

logger = logging.getLogger(__name__)

# ── Mock Kafka producer (no broker required for dev/demo) ──────────────────────
import os

try:
    from kafka import KafkaProducer as _RealProducer
    _KAFKA_INSTALLED = True
except ImportError:
    _KAFKA_INSTALLED = False

# Only use a real broker when explicitly opted in via environment variable.
# This avoids a crash when kafka-python is installed but no broker is running.
_REAL_KAFKA = _KAFKA_INSTALLED and os.environ.get("USE_REAL_KAFKA", "").lower() in ("1", "true", "yes")


class _MockKafkaProducer:
    """In-process pub/sub used when no Kafka broker is available."""
    _subscribers: dict[str, list] = {}
    _lock = threading.Lock()

    def send(self, topic: str, value: bytes):
        with self._lock:
            subs = self._subscribers.get(topic, [])
        for cb in subs:
            try:
                cb(json.loads(value))
            except Exception as exc:
                logger.warning("Mock subscriber error: %s", exc)
        return self   # chainable

    def flush(self):
        pass

    @classmethod
    def subscribe(cls, topic: str, callback):
        with cls._lock:
            cls._subscribers.setdefault(topic, []).append(callback)


# ── Stock universe ─────────────────────────────────────────────────────────────

class StockProducer:
    TOPIC = "stock-prices"

    STOCKS: dict = {
        "AAPL":  {"name": "Apple Inc.",       "base_price": 189.45, "color": "#00e5a0"},
        "TSLA":  {"name": "Tesla Inc.",        "base_price": 248.30, "color": "#4d9fff"},
        "NVDA":  {"name": "NVIDIA Corp.",      "base_price": 875.20, "color": "#a78bfa"},
        "GOOGL": {"name": "Alphabet Inc.",     "base_price": 175.80, "color": "#ffb84d"},
        "MSFT":  {"name": "Microsoft Corp.",   "base_price": 415.60, "color": "#00e5a0"},
        "AMZN":  {"name": "Amazon.com",        "base_price": 196.30, "color": "#ff4d6a"},
        "META":  {"name": "Meta Platforms",    "base_price": 528.90, "color": "#4d9fff"},
        "BRK":   {"name": "Berkshire Hath.",   "base_price": 622.10, "color": "#a78bfa"},
    }

    TICK_INTERVAL = 0.8   # seconds between ticks (matches original 800 ms)

    def __init__(self, bootstrap_servers: str = "localhost:9092"):
        self._prices = {sym: meta["base_price"] for sym, meta in self.STOCKS.items()}

        if _REAL_KAFKA:
            self._producer = _RealProducer(
                bootstrap_servers=[bootstrap_servers],
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            )
            logger.info("Connected to Kafka broker at %s", bootstrap_servers)
        else:
            self._producer = _MockKafkaProducer()
            logger.info("Using mock in-process Kafka producer (no broker required)")

    # ── Public helpers ─────────────────────────────────────────────────────────

    @classmethod
    def subscribe_mock(cls, topic: str, callback):
        """Used by the mock consumer to wire up in-process delivery."""
        _MockKafkaProducer.subscribe(topic, callback)

    def run_forever(self):
        """Produce price ticks indefinitely (run in a daemon thread)."""
        logger.info("Stock producer started — publishing to topic '%s'", self.TOPIC)
        while True:
            self._tick()
            time.sleep(self.TICK_INTERVAL)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _tick(self):
        now = int(time.time() * 1000)   # ms epoch
        for sym, price in self._prices.items():
            # Random-walk: small drift + volatility
            volatility = 0.002 + random.random() * 0.003
            drift      = (random.random() - 0.495) * volatility
            new_price  = round(price * (1 + drift), 2)
            self._prices[sym] = new_price

            volume = random.randint(1_000, 50_000)

            message = {
                "symbol":    sym,
                "price":     new_price,
                "timestamp": now,
                "volume":    volume,
            }
            self._producer.send(self.TOPIC, value=json.dumps(message).encode())

        self._producer.flush()
