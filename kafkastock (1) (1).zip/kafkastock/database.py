"""
database.py
SQLite persistence layer for KafkaStock.

Schema
------
prices (id, symbol, price, timestamp, volume)
"""

import sqlite3
import threading
import logging
from typing import Any

logger = logging.getLogger(__name__)


class Database:
    """Thread-safe SQLite wrapper."""

    DDL = """
    CREATE TABLE IF NOT EXISTS prices (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol    TEXT    NOT NULL,
        price     REAL    NOT NULL,
        timestamp INTEGER NOT NULL,   -- ms epoch
        volume    INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_prices_symbol ON prices (symbol);
    CREATE INDEX IF NOT EXISTS idx_prices_ts     ON prices (timestamp);
    """

    # Queries used by the API
    QUERY_HISTORY = """
        SELECT symbol, price, timestamp, volume
        FROM   prices
        WHERE  symbol = ?
        ORDER  BY timestamp DESC
        LIMIT  ?
    """

    QUERY_LATEST = """
        SELECT price, timestamp
        FROM   prices
        WHERE  symbol = ?
        ORDER  BY timestamp DESC
        LIMIT  1
    """

    QUERY_STATS = """
        SELECT
            symbol,
            ROUND(AVG(price), 2)                     AS avg_price,
            MAX(price)                               AS high,
            MIN(price)                               AS low,
            ROUND(MAX(price) - MIN(price), 4)        AS spike,
            COUNT(*)                                 AS ticks,
            SUM(volume)                              AS total_volume
        FROM  prices
        WHERE symbol = ?
    """

    # Preset queries available in the UI
    PRESET_QUERIES: dict[str, str] = {
        "avg":   "SELECT symbol, ROUND(AVG(price),2) AS avg_price, COUNT(*) AS ticks "
                 "FROM prices GROUP BY symbol ORDER BY avg_price DESC",
        "spike": "SELECT symbol, MAX(price) AS high, MIN(price) AS low, "
                 "ROUND(MAX(price)-MIN(price),2) AS spike "
                 "FROM prices GROUP BY symbol ORDER BY spike DESC",
        "range": "SELECT symbol, MIN(price) AS day_low, MAX(price) AS day_high, "
                 "ROUND((MAX(price)/MIN(price)*100)-100, 3) AS pct_range "
                 "FROM prices GROUP BY symbol ORDER BY pct_range DESC",
        "last":  "SELECT symbol, price AS latest_price, timestamp "
                 "FROM prices WHERE id IN "
                 "(SELECT MAX(id) FROM prices GROUP BY symbol) ORDER BY symbol",
        "top":   "SELECT symbol, "
                 "ROUND((MAX(price)-MIN(price))/MIN(price)*100, 2) AS gain_pct "
                 "FROM prices GROUP BY symbol ORDER BY gain_pct DESC",
        "vol":   "SELECT symbol, SUM(volume) AS total_volume, "
                 "ROUND(AVG(volume),0) AS avg_volume, COUNT(*) AS ticks "
                 "FROM prices GROUP BY symbol ORDER BY total_volume DESC",
    }

    # Maximum rows to keep (prune older rows automatically)
    MAX_ROWS = 50_000

    def __init__(self, path: str = "stocks.db"):
        self._path  = path
        self._local = threading.local()   # one connection per thread
        self._lock  = threading.Lock()    # serialise writes
        self._write_count = 0
        self._init_schema()

    # ── Connection management ──────────────────────────────────────────────────

    @property
    def _conn(self) -> sqlite3.Connection:
        if not getattr(self._local, "conn", None):
            conn = sqlite3.connect(self._path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = conn
        return self._local.conn

    def _init_schema(self):
        with self._lock:
            self._conn.executescript(self.DDL)
            self._conn.commit()
        logger.info("Database initialised at '%s'", self._path)

    # ── Write operations ───────────────────────────────────────────────────────

    def insert_price(self, symbol: str, price: float, timestamp: int, volume: int):
        with self._lock:
            self._conn.execute(
                "INSERT INTO prices (symbol, price, timestamp, volume) VALUES (?,?,?,?)",
                (symbol, price, timestamp, volume)
            )
            self._conn.commit()
            self._write_count += 1

        # Prune every 500 writes to keep DB size bounded
        if self._write_count % 500 == 0:
            self._prune()

    def _prune(self):
        """Delete oldest rows beyond MAX_ROWS."""
        with self._lock:
            self._conn.execute("""
                DELETE FROM prices
                WHERE id NOT IN (
                    SELECT id FROM prices ORDER BY id DESC LIMIT ?
                )
            """, (self.MAX_ROWS,))
            self._conn.commit()

    # ── Read operations ────────────────────────────────────────────────────────

    def get_history(self, symbol: str, limit: int = 300) -> list[dict]:
        rows = self._conn.execute(self.QUERY_HISTORY, (symbol, limit)).fetchall()
        # Return in chronological order (ASC)
        result = [dict(r) for r in reversed(rows)]
        return result

    def get_latest(self, symbol: str) -> dict | None:
        row = self._conn.execute(self.QUERY_LATEST, (symbol,)).fetchone()
        return dict(row) if row else None

    def get_stats(self, symbol: str) -> dict:
        row = self._conn.execute(self.QUERY_STATS, (symbol,)).fetchone()
        return dict(row) if row else {}

    def run_query(self, sql: str) -> list[dict]:
        """
        Execute an arbitrary SELECT query safely.
        Raises ValueError for non-SELECT statements.
        """
        normalized = sql.strip().lower()
        if not normalized.startswith("select"):
            raise ValueError("Only SELECT queries are allowed.")
        # Block obviously dangerous statements
        for kw in ("drop", "delete", "insert", "update", "alter", "create"):
            if kw in normalized:
                raise ValueError(f"Keyword '{kw.upper()}' is not permitted in queries.")
        rows = self._conn.execute(sql).fetchall()
        return [dict(r) for r in rows]

    def row_count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) AS n FROM prices").fetchone()
        return row["n"] if row else 0
