"""
KafkaStock - Flask + Kafka + SQLite Stock Price Tracker
Main application entry point.
"""

import json
import time
import threading
import queue
from flask import Flask, render_template, Response, jsonify, request
from kafka_producer import StockProducer
from kafka_consumer import StockConsumer
from database import Database

app = Flask(__name__)

# ── In-memory price state (latest values per symbol) ──────────────────────────
price_state: dict = {}
state_lock = threading.Lock()

# SSE client queues: each connected browser gets its own queue
sse_clients: list[queue.Queue] = []
clients_lock = threading.Lock()

# ── Database ───────────────────────────────────────────────────────────────────
db = Database("stocks.db")

# ── Kafka producer (runs in background thread) ─────────────────────────────────
producer = StockProducer()


def broadcast(event_data: dict):
    """Push a JSON event to every connected SSE client."""
    payload = f"data: {json.dumps(event_data)}\n\n"
    with clients_lock:
        dead = []
        for q in sse_clients:
            try:
                q.put_nowait(payload)
            except queue.Full:
                dead.append(q)
        for q in dead:
            sse_clients.remove(q)


def consumer_thread():
    """Long-running thread: consume Kafka messages, persist to DB, broadcast via SSE."""
    consumer = StockConsumer(on_message=handle_kafka_message)
    consumer.start()          # blocks internally; runs forever


def handle_kafka_message(msg: dict):
    """Called by the consumer for each Kafka price tick."""
    sym   = msg["symbol"]
    price = msg["price"]
    ts    = msg["timestamp"]
    vol   = msg.get("volume", 0)

    # Persist
    db.insert_price(sym, price, ts, vol)

    # Update in-memory state
    with state_lock:
        prev = price_state.get(sym)
        if prev is None:
            prev = {"open": price, "high": price, "low": price,
                    "price": price, "vol": vol, "chg_pct": 0.0, "symbol": sym,
                    "name": StockProducer.STOCKS[sym]["name"],
                    "color": StockProducer.STOCKS[sym]["color"]}
        prev["price"]   = price
        prev["high"]    = max(prev["high"], price)
        prev["low"]     = min(prev["low"], price)
        prev["vol"]    += vol
        prev["chg_pct"] = round((price - prev["open"]) / prev["open"] * 100, 2)
        price_state[sym] = prev

    # Broadcast to SSE clients
    broadcast({"type": "tick", "symbol": sym, "price": price,
               "timestamp": ts, "state": price_state.get(sym)})


# ── Routes ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    symbols = list(StockProducer.STOCKS.keys())
    stocks_meta = [
        {"sym": k, "name": v["name"], "color": v["color"],
         "price": v["base_price"]}
        for k, v in StockProducer.STOCKS.items()
    ]
    return render_template("index.html", stocks=stocks_meta)


@app.route("/stream")
def stream():
    """Server-Sent Events endpoint."""
    q: queue.Queue = queue.Queue(maxsize=200)
    with clients_lock:
        sse_clients.append(q)

    def event_generator():
        # Send initial state snapshot
        with state_lock:
            snapshot = dict(price_state)
        yield f"data: {json.dumps({'type': 'snapshot', 'state': snapshot})}\n\n"

        try:
            while True:
                try:
                    msg = q.get(timeout=30)
                    yield msg
                except queue.Empty:
                    yield ": heartbeat\n\n"   # keep connection alive
        except GeneratorExit:
            pass
        finally:
            with clients_lock:
                try:
                    sse_clients.remove(q)
                except ValueError:
                    pass

    return Response(event_generator(),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


@app.route("/api/history/<symbol>")
def history(symbol: str):
    """Return the last N price rows for a symbol."""
    limit = int(request.args.get("limit", 300))
    rows = db.get_history(symbol.upper(), limit)
    return jsonify(rows)


@app.route("/api/query", methods=["POST"])
def run_query():
    """Execute a safe read-only SQL query and return results."""
    body = request.get_json(force=True)
    sql  = body.get("sql", "").strip()
    if not sql:
        return jsonify({"error": "Empty query"}), 400
    try:
        rows = db.run_query(sql)
        return jsonify({"rows": rows})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/stats")
def stats():
    """Aggregate stats for the bottom bar."""
    symbol = request.args.get("symbol", "AAPL").upper()
    data   = db.get_stats(symbol)
    return jsonify(data)


# ── Startup ────────────────────────────────────────────────────────────────────

def start_background_services():
    # Seed initial state from DB (last known prices)
    for sym, meta in StockProducer.STOCKS.items():
        row = db.get_latest(sym)
        if row:
            price = row["price"]
        else:
            price = meta["base_price"]
        with state_lock:
            price_state[sym] = {
                "symbol": sym, "name": meta["name"], "color": meta["color"],
                "open": price, "price": price,
                "high": price, "low": price, "vol": 0, "chg_pct": 0.0
            }

    # Kafka consumer thread
    t_consumer = threading.Thread(target=consumer_thread, daemon=True)
    t_consumer.start()

    # Kafka producer thread (simulated ticks)
    t_producer = threading.Thread(target=producer.run_forever, daemon=True)
    t_producer.start()


start_background_services()

if __name__ == "__main__":
    app.run(debug=False, threaded=True, port=5000)
