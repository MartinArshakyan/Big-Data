"""
kafka_consumer.py
Consumes stock price messages from Kafka and forwards them to app.py.

In production replace the mock with:
    from kafka import KafkaConsumer
    consumer = KafkaConsumer(
        "stock-prices",
        bootstrap_servers=["localhost:9092"],
        value_deserializer=lambda m: json.loads(m.decode()),
        auto_offset_reset="latest",
        group_id="kafkastock-group",
    )
    for message in consumer:
        on_message(message.value)
"""

import json
import time
import logging
import threading

logger = logging.getLogger(__name__)

import os

try:
    from kafka import KafkaConsumer as _RealConsumer
    _KAFKA_INSTALLED = True
except ImportError:
    _KAFKA_INSTALLED = False

_REAL_KAFKA = _KAFKA_INSTALLED and os.environ.get("USE_REAL_KAFKA", "").lower() in ("1", "true", "yes")

from kafka_producer import StockProducer   # for TOPIC constant & mock wiring


class StockConsumer:
    """
    Thin wrapper around KafkaConsumer (real or mock).
    Call .start() to begin consuming in the current thread (blocking).
    """

    def __init__(self, on_message, bootstrap_servers: str = "localhost:9092",
                 group_id: str = "kafkastock-group"):
        self._on_message = on_message
        self._bootstrap  = bootstrap_servers
        self._group_id   = group_id

    def start(self):
        if _REAL_KAFKA:
            self._start_real()
        else:
            self._start_mock()

    # ── Real Kafka ─────────────────────────────────────────────────────────────

    def _start_real(self):
        consumer = _RealConsumer(
            StockProducer.TOPIC,
            bootstrap_servers=[self._bootstrap],
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
            auto_offset_reset="latest",
            enable_auto_commit=True,
            group_id=self._group_id,
        )
        logger.info("Real Kafka consumer started, listening on '%s'",
                    StockProducer.TOPIC)
        for message in consumer:
            try:
                self._on_message(message.value)
            except Exception as exc:
                logger.error("Consumer handler error: %s", exc)

    # ── Mock (in-process) ──────────────────────────────────────────────────────

    def _start_mock(self):
        """Register a callback on the mock producer's pub/sub bus."""
        logger.info("Mock Kafka consumer started, subscribed to '%s'",
                    StockProducer.TOPIC)

        delivered = threading.Event()

        def _cb(msg):
            try:
                self._on_message(msg)
            except Exception as exc:
                logger.error("Mock consumer handler error: %s", exc)
            delivered.set()

        StockProducer.subscribe_mock(StockProducer.TOPIC, _cb)

        # Block forever (mimics the real consumer loop)
        while True:
            delivered.wait(timeout=60)
            delivered.clear()
