# KafkaStock — Flask + Kafka + SQLite Dashboard

Real-time stock price tracker: identical UI to the original single-file HTML,
now backed by a proper Python backend.

```
kafkastock/
├── app.py              ← Flask routes, SSE broadcasting, startup wiring
├── kafka_producer.py   ← Simulates price ticks → publishes to Kafka topic
├── kafka_consumer.py   ← Consumes messages → calls handler in app.py
├── database.py         ← SQLite persistence + safe query execution
├── requirements.txt
├── templates/
│   └── index.html      ← Dashboard UI (Jinja2 template)
└── static/
    └── css/
        └── dashboard.css
```

## Quick start (no Kafka broker needed)

```bash
pip install flask
python app.py
# Open http://localhost:5000
```

The app uses an **in-process mock Kafka bus** when `kafka-python` is not
installed or no broker is reachable, so it works out of the box for dev/demo.

## With a real Kafka broker

```bash
# Start Kafka (Docker example)
docker run -d -p 9092:9092 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 \
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT \
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 \
  apache/kafka:latest

pip install flask kafka-python
python app.py
```

The producer publishes to topic **`stock-prices`**; the consumer subscribes
with group-id **`kafkastock-group`**.

## Architecture

```
[StockProducer]  ──(JSON msgs)──►  Kafka topic: stock-prices
                                          │
                                  [StockConsumer]
                                          │
                             handle_kafka_message()
                              ├─ db.insert_price()   ← SQLite WAL
                              └─ broadcast()         ← SSE queues
                                          │
                              Browser  ◄── /stream (SSE)
                                          │
                              Browser  ◄── /api/history/<sym>
                              Browser  ◄── /api/query  (SQL)
                              Browser  ◄── /api/stats
```

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET  | `/`                     | Dashboard HTML |
| GET  | `/stream`               | SSE event stream (ticks + snapshots) |
| GET  | `/api/history/<symbol>` | Last N price rows for a symbol |
| POST | `/api/query`            | Execute a SELECT query → JSON rows |
| GET  | `/api/stats`            | Aggregate stats for a symbol |

## SQL panel

Only `SELECT` statements are allowed. Dangerous keywords (`DROP`, `DELETE`,
`INSERT`, `UPDATE`, `ALTER`, `CREATE`) are blocked server-side.

Preset queries:
- **AVG daily price per ticker**
- **Highest price spikes**
- **Volume by ticker**
- **Daily price range**
- **Latest prices**
- **Top gainers today**

Ctrl+Enter also runs the query.
